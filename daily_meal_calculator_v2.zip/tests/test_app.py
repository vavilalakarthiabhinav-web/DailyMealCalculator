"""Automated unit and integration test suite for Daily Meal Cost Calculator."""

import os
import tempfile
import unittest

from daily_meal_calculator.analytics import (
    calculate_burn_rate,
    detect_statistical_anomalies,
    export_markdown_report,
    summarise,
)
from daily_meal_calculator.database import MealRepository
from daily_meal_calculator.models import (
    MealEntry,
    validate_date,
    validate_item_name,
    validate_meal_type,
    validate_price,
    validate_quantity,
)


class TestModelsAndValidation(unittest.TestCase):
    def test_meal_entry_rounding_and_high_cost_flag(self):
        entry = MealEntry("ML-0001", "2026-11-20", "Dinner", "Catering Platter", 200.556, 2, daily_limit=700.0)
        self.assertEqual(entry.unit_price, 200.56)
        self.assertEqual(entry.total_cost, 401.12)
        self.assertEqual(entry.budget_flag, "HIGH_COST")

    def test_normal_budget_flag(self):
        entry = MealEntry("ML-0002", "2026-11-20", "Snack", "Almonds", 65.0, 1, daily_limit=700.0)
        self.assertEqual(entry.budget_flag, "NORMAL")

    def test_invalid_inputs_raise_value_error(self):
        with self.assertRaises(ValueError):
            validate_item_name("   ")
        with self.assertRaises(ValueError):
            validate_item_name("Bad@Name#!")
        with self.assertRaises(ValueError):
            validate_date("20-11-2026")
        with self.assertRaises(ValueError):
            validate_meal_type("Midnight")
        with self.assertRaises(ValueError):
            validate_price(float("nan"))
        with self.assertRaises(ValueError):
            validate_price(-10.0)
        with self.assertRaises(ValueError):
            validate_quantity(0)
        with self.assertRaises(ValueError):
            validate_quantity(100)


class TestDatabaseAndAnalytics(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db_path = os.path.join(self.tmp.name, "test.db")
        self.repo = MealRepository(self.db_path)

    def tearDown(self):
        self.tmp.cleanup()

    def test_add_and_sql_pagination(self):
        self.repo.seed_demo_data()
        self.assertEqual(self.repo.count_meals(), 35)
        page1 = self.repo.fetch_page(page=1, page_size=10)
        page4 = self.repo.fetch_page(page=4, page_size=10)
        self.assertEqual(len(page1), 10)
        self.assertEqual(len(page4), 5)

    def test_filtered_query_by_category(self):
        self.repo.seed_demo_data()
        dinners = self.repo.count_meals(meal_type="Dinner")
        self.assertEqual(dinners, 10)

    def test_csv_import_handles_valid_and_invalid_rows(self):
        csv_path = os.path.join(self.tmp.name, "import.csv")
        with open(csv_path, "w", encoding="utf-8") as f:
            f.write("date,meal_type,item_name,unit_price,quantity\n")
            f.write("2026-11-21,Lunch,Dal Tadka,180.0,1\n")
            f.write("bad-date,Lunch,Invalid Row,100.0,1\n")
            f.write("2026-11-21,Dinner,Paneer Curry,-50.0,1\n")

        added, rejected, errors = self.repo.import_csv(csv_path)
        self.assertEqual(added, 1)
        self.assertEqual(rejected, 2)
        self.assertEqual(len(errors), 2)

    def test_analytics_anomalies_and_burn_rate(self):
        self.repo.seed_demo_data()
        records = self.repo.fetch_all()
        summary = summarise(records, daily_limit=700.0)
        self.assertEqual(summary["entries"], 35)
        self.assertEqual(summary["days"], 10)
        self.assertTrue(len(summary["over_budget"]) >= 3)

        anomalies = detect_statistical_anomalies(records, z_threshold=2.0)
        self.assertTrue(any(item.item_name == "Catering Platter" for item, _ in anomalies))

        burn = calculate_burn_rate(records, window_days=7)
        self.assertGreater(burn["rolling_avg"], 0)
        self.assertEqual(burn["projected_30d"], round(burn["rolling_avg"] * 30, 2))

    def test_markdown_report_export(self):
        self.repo.seed_demo_data()
        md_path = os.path.join(self.tmp.name, "report.md")
        out = export_markdown_report(self.repo.fetch_all(), 700.0, "₹", md_path)
        self.assertTrue(os.path.exists(out))
        with open(out, encoding="utf-8") as f:
            content = f.read()
        self.assertIn("Meal Cost Summary Report", content)
        self.assertIn("Statistical Anomalies", content)

    def test_configurable_settings(self):
        self.repo.set_setting("daily_limit", "850.0")
        self.assertEqual(self.repo.get_daily_limit(), 850.0)


if __name__ == "__main__":
    unittest.main()
