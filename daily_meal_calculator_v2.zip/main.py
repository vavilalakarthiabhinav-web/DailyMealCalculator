"""Application entry point with structured rotating file logging."""

import logging
from logging.handlers import RotatingFileHandler

from daily_meal_calculator.cli import DailyMealCLI
from daily_meal_calculator.database import MealRepository


def configure_logging(log_file: str = "meal_tracker.log") -> None:
    handler = RotatingFileHandler(log_file, maxBytes=512_000, backupCount=3, encoding="utf-8")
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        handlers=[handler],
    )


def main() -> None:
    configure_logging()
    repo = MealRepository("meal_tracker.db")
    app = DailyMealCLI(repo)
    app.run()


if __name__ == "__main__":
    main()
