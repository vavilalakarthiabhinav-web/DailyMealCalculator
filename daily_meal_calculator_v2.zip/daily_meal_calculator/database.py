"""SQLite Data Access Layer with indexing, SQL pagination, and JSON/CSV I/O."""

import csv
from datetime import datetime, timedelta
import json
import logging
import os
import sqlite3
from typing import List, Optional, Tuple

from .models import (
    DEFAULT_CURRENCY,
    DEFAULT_DAILY_LIMIT,
    MealEntry,
)

logger = logging.getLogger(__name__)


class MealRepository:
    """Manages SQLite persistence, indexed queries, pagination, and bulk I/O."""

    def __init__(self, db_path: str = "meal_tracker.db"):
        self.db_path = db_path
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS meals (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    entry_id TEXT UNIQUE NOT NULL,
                    date TEXT NOT NULL,
                    meal_type TEXT NOT NULL,
                    item_name TEXT NOT NULL,
                    unit_price REAL NOT NULL,
                    quantity INTEGER NOT NULL,
                    total_cost REAL NOT NULL,
                    budget_flag TEXT NOT NULL
                )
                """
            )
            conn.execute("CREATE INDEX IF NOT EXISTS idx_meals_date ON meals(date)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_meals_type ON meals(meal_type)")
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS settings (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                )
                """
            )
            conn.execute(
                "INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)",
                ("daily_limit", str(DEFAULT_DAILY_LIMIT)),
            )
            conn.execute(
                "INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)",
                ("currency", DEFAULT_CURRENCY),
            )
        logger.info("Initialized SQLite database at %s", self.db_path)

    # ---------- Settings ----------

    def get_setting(self, key: str, default: str) -> str:
        with self._connect() as conn:
            row = conn.execute("SELECT value FROM settings WHERE key = ?", (key,)).fetchone()
            return row["value"] if row else default

    def set_setting(self, key: str, value: str) -> None:
        with self._connect() as conn:
            conn.execute(
                "INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)",
                (key, str(value)),
            )
        logger.info("Updated setting %s=%s", key, value)

    def get_daily_limit(self) -> float:
        return float(self.get_setting("daily_limit", str(DEFAULT_DAILY_LIMIT)))

    def get_currency(self) -> str:
        return self.get_setting("currency", DEFAULT_CURRENCY)

    # ---------- CRUD & Pagination ----------

    def _next_entry_id(self, conn: sqlite3.Connection) -> str:
        row = conn.execute("SELECT MAX(id) AS max_id FROM meals").fetchone()
        next_num = (row["max_id"] or 0) + 1
        return f"ML-{next_num:04d}"

    def add_meal(
        self,
        date: str,
        meal_type: str,
        item_name: str,
        unit_price: float,
        quantity: int,
    ) -> MealEntry:
        daily_limit = self.get_daily_limit()
        with self._connect() as conn:
            entry_id = self._next_entry_id(conn)
            entry = MealEntry(
                entry_id=entry_id,
                date=date,
                meal_type=meal_type,
                item_name=item_name,
                unit_price=unit_price,
                quantity=quantity,
                daily_limit=daily_limit,
            )
            conn.execute(
                """
                INSERT INTO meals (entry_id, date, meal_type, item_name,
                                   unit_price, quantity, total_cost, budget_flag)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    entry.entry_id,
                    entry.date,
                    entry.meal_type,
                    entry.item_name,
                    entry.unit_price,
                    entry.quantity,
                    entry.total_cost,
                    entry.budget_flag,
                ),
            )
        logger.info("Added meal %s (%s, %.2f)", entry.entry_id, entry.item_name, entry.total_cost)
        return entry

    def _row_to_entry(self, row: sqlite3.Row, daily_limit: float) -> MealEntry:
        return MealEntry(
            entry_id=row["entry_id"],
            date=row["date"],
            meal_type=row["meal_type"],
            item_name=row["item_name"],
            unit_price=row["unit_price"],
            quantity=row["quantity"],
            daily_limit=daily_limit,
        )

    def count_meals(
        self,
        keyword: Optional[str] = None,
        meal_type: Optional[str] = None,
        date: Optional[str] = None,
    ) -> int:
        query = "SELECT COUNT(*) AS cnt FROM meals WHERE 1=1"
        params: list = []
        if keyword:
            query += " AND LOWER(item_name) LIKE ?"
            params.append(f"%{keyword.lower()}%")
        if meal_type:
            query += " AND meal_type = ?"
            params.append(meal_type)
        if date:
            query += " AND date = ?"
            params.append(date)
        with self._connect() as conn:
            return int(conn.execute(query, params).fetchone()["cnt"])

    def fetch_page(
        self,
        page: int = 1,
        page_size: int = 12,
        keyword: Optional[str] = None,
        meal_type: Optional[str] = None,
        date: Optional[str] = None,
    ) -> List[MealEntry]:
        """True SQL-level pagination using LIMIT and OFFSET."""
        offset = max(page - 1, 0) * page_size
        query = "SELECT * FROM meals WHERE 1=1"
        params: list = []
        if keyword:
            query += " AND LOWER(item_name) LIKE ?"
            params.append(f"%{keyword.lower()}%")
        if meal_type:
            query += " AND meal_type = ?"
            params.append(meal_type)
        if date:
            query += " AND date = ?"
            params.append(date)
        query += " ORDER BY date DESC, id DESC LIMIT ? OFFSET ?"
        params.extend([page_size, offset])

        daily_limit = self.get_daily_limit()
        with self._connect() as conn:
            rows = conn.execute(query, params).fetchall()
        return [self._row_to_entry(r, daily_limit) for r in rows]

    def fetch_all(self) -> List[MealEntry]:
        daily_limit = self.get_daily_limit()
        with self._connect() as conn:
            rows = conn.execute("SELECT * FROM meals ORDER BY date ASC, id ASC").fetchall()
        return [self._row_to_entry(r, daily_limit) for r in rows]

    def get_day_total(self, date: str) -> float:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT COALESCE(SUM(total_cost), 0.0) AS total FROM meals WHERE date = ?",
                (date,),
            ).fetchone()
        return round(float(row["total"]), 2)

    def clear_all(self) -> None:
        with self._connect() as conn:
            conn.execute("DELETE FROM meals")
            conn.execute("DELETE FROM sqlite_sequence WHERE name='meals'")
        logger.warning("Cleared all meal records from %s", self.db_path)

    # ---------- Bulk Import / Export ----------

    def export_json_csv(
        self, json_path: str = "meal_records.json", csv_path: str = "meal_records.csv"
    ) -> Tuple[str, str]:
        entries = self.fetch_all()
        rows = [e.to_dict() for e in entries]
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(rows, f, indent=2)

        columns = [
            "entry_id",
            "date",
            "meal_type",
            "item_name",
            "unit_price",
            "quantity",
            "total_cost",
            "budget_flag",
        ]
        with open(csv_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=columns)
            writer.writeheader()
            writer.writerows(rows)

        logger.info("Exported %d records to %s and %s", len(rows), json_path, csv_path)
        return json_path, csv_path

    def import_csv(self, csv_path: str) -> Tuple[int, int, List[str]]:
        """Import meals from CSV with row-level validation. Returns (added, rejected, errors)."""
        if not os.path.exists(csv_path):
            raise FileNotFoundError(f"CSV file not found: {csv_path}")

        added = 0
        rejected = 0
        errors: List[str] = []

        with open(csv_path, encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for line_no, row in enumerate(reader, start=2):
                try:
                    self.add_meal(
                        date=row["date"],
                        meal_type=row["meal_type"],
                        item_name=row["item_name"],
                        unit_price=float(row["unit_price"]),
                        quantity=int(row["quantity"]),
                    )
                    added += 1
                except (KeyError, ValueError, TypeError) as exc:
                    rejected += 1
                    msg = f"Row {line_no}: {exc}"
                    errors.append(msg)
                    logger.warning("CSV import rejected %s", msg)

        logger.info("CSV import finished: %d added, %d rejected", added, rejected)
        return added, rejected, errors

    def seed_demo_data(self) -> int:
        """Replace existing records with 35 realistic Indian-priced demo meals."""
        self.clear_all()
        start = datetime(2026, 11, 10)
        samples = [
            (0, "Breakfast", "Oatmeal & Chia Bowl", 110.00, 1),
            (0, "Lunch", "Grilled Chicken Quinoa Salad", 255.00, 1),
            (0, "Dinner", "Baked Salmon & Asparagus", 330.00, 1),
            (0, "Snack", "Roasted Almonds Pack", 65.00, 1),
            (1, "Breakfast", "Greek Yogurt Parfait", 96.00, 1),
            (1, "Lunch", "Lentil & Spinach Soup", 170.00, 1),
            (1, "Dinner", "Vegetable Stir Fry & Tofu", 224.00, 1),
            (1, "Beverage", "Matcha Green Tea", 85.00, 1),
            (2, "Breakfast", "Avocado Toast & Poached Egg", 180.00, 1),
            (2, "Lunch", "Turkey Whole Wheat Wrap", 210.00, 1),
            (2, "Dinner", "Paneer Tikka & Brown Rice", 268.00, 1),
            (3, "Breakfast", "Banana Peanut Butter Smoothie", 125.00, 1),
            (3, "Lunch", "Chickpea Buddha Bowl", 220.00, 1),
            (3, "Snack", "Fresh Apple Slices", 35.00, 2),
            (3, "Dinner", "Herb Roasted Cod & Potatoes", 296.00, 1),
            (4, "Breakfast", "Scrambled Eggs & Sourdough", 150.00, 1),
            (4, "Lunch", "Black Bean Burrito Bowl", 218.00, 1),
            (4, "Dinner", "Mushroom Risotto", 304.00, 1),
            (4, "Beverage", "Cold Brew Coffee", 78.00, 1),
            (5, "Breakfast", "Steel Cut Oats & Berries", 102.00, 1),
            (5, "Lunch", "Mediterranean Falafel Plate", 236.00, 1),
            (5, "Dinner", "Grilled Shrimp Tacos", 290.00, 1),
            (6, "Breakfast", "Whole Grain Pancakes", 164.00, 1),
            (6, "Lunch", "Caprese Pesto Panini", 195.00, 1),
            (6, "Snack", "Dark Chocolate Square", 50.00, 1),
            (6, "Dinner", "Eggplant Parmesan", 272.00, 1),
            (7, "Breakfast", "Chia Seed Pudding", 108.00, 1),
            (7, "Lunch", "Tuna Nicoise Salad", 248.00, 1),
            (7, "Dinner", "Teriyaki Chicken Bowl", 278.00, 1),
            (8, "Breakfast", "Veggie Omelette", 156.00, 1),
            (8, "Lunch", "Minestrone Soup & Roll", 178.00, 1),
            (8, "Dinner", "Beef & Broccoli Stir Fry", 284.00, 1),
            (8, "Beverage", "Sparkling Mineral Water", 42.00, 2),
            (9, "Snack", "Single Espresso Shot", 30.00, 1),
            (9, "Dinner", "Catering Platter", 440.00, 2),
        ]
        for offset, meal_type, name, price, qty in samples:
            date = (start + timedelta(days=offset)).strftime("%Y-%m-%d")
            self.add_meal(date, meal_type, name, price, qty)
        logger.info("Seeded %d demo meal records", len(samples))
        return len(samples)
