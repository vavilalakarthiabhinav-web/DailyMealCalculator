"""Interactive terminal UI (strictly separated from storage and analytics logic)."""

import logging
from typing import Optional

from .analytics import export_markdown_report, summarise
from .database import MealRepository
from .models import (
    MAX_PRICE,
    MAX_QTY,
    MEAL_TYPES,
    MIN_PRICE,
    MIN_QTY,
    validate_date,
    validate_item_name,
    validate_meal_type,
    validate_price,
    validate_quantity,
)

logger = logging.getLogger(__name__)


class DailyMealCLI:
    """Presentation layer for the Daily Meal Cost Calculator."""

    def __init__(self, repo: MealRepository):
        self.repo = repo

    def _prompt_until_valid(self, prompt: str, validator):
        while True:
            raw = input(prompt)
            try:
                return validator(raw)
            except ValueError as err:
                print(f"  Invalid input: {err}")

    def _print_paginated(
        self,
        keyword: Optional[str] = None,
        meal_type: Optional[str] = None,
        date: Optional[str] = None,
        page_size: int = 12,
    ) -> None:
        total = self.repo.count_meals(keyword=keyword, meal_type=meal_type, date=date)
        if total == 0:
            print("  No records found.")
            return

        cur = self.repo.get_currency()
        page = 1
        header = (
            f"{'ID':<8} | {'Date':<10} | {'Category':<10} | {'Item':<26} | "
            f"{'Price':>9} | {'Qty':>3} | {'Total':>10} | {'Status':<9}"
        )
        line = "-" * len(header)

        while True:
            rows = self.repo.fetch_page(
                page=page, page_size=page_size, keyword=keyword, meal_type=meal_type, date=date
            )
            if not rows:
                break
            print(f"\n{line}\n{header}\n{line}")
            for r in rows:
                name = r.item_name if len(r.item_name) <= 26 else r.item_name[:23] + "..."
                print(
                    f"{r.entry_id:<8} | {r.date:<10} | {r.meal_type:<10} | {name:<26} | "
                    f"{cur}{r.unit_price:>8.2f} | {r.quantity:>3} | "
                    f"{cur}{r.total_cost:>9.2f} | {r.budget_flag:<9}"
                )
            print(line)
            shown = min(page * page_size, total)
            if shown >= total:
                break
            ans = input(f"  Page {page} ({shown}/{total}). Enter for next, 'q' to stop: ").strip().lower()
            if ans == "q":
                break
            page += 1

    def handle_add(self) -> None:
        cur = self.repo.get_currency()
        limit = self.repo.get_daily_limit()
        print("\n--- Add a Meal ---")
        date = self._prompt_until_valid("  Date (YYYY-MM-DD, Enter for today): ", validate_date)
        meal_type = self._prompt_until_valid(
            f"  Meal type ({'/'.join(MEAL_TYPES)}): ", validate_meal_type
        )
        name = self._prompt_until_valid("  Item name: ", validate_item_name)
        price = self._prompt_until_valid(
            f"  Unit price ({cur}{MIN_PRICE:.2f}-{cur}{MAX_PRICE:.2f}): ", validate_price
        )
        qty = self._prompt_until_valid(
            f"  Quantity ({MIN_QTY}-{MAX_QTY}): ", validate_quantity
        )

        entry = self.repo.add_meal(date, meal_type, name, price, qty)
        day_total = self.repo.get_day_total(date)
        print(f"\n  Saved {entry.entry_id}: {entry.quantity} x {entry.item_name} = {cur}{entry.total_cost:.2f}")
        print(f"  Total for {date}: {cur}{day_total:.2f} (limit {cur}{limit:.2f})")
        if day_total > limit:
            print(f"  ALERT: {cur}{day_total - limit:.2f} over your daily budget!")

    def handle_search(self) -> None:
        print("\n--- View / Search Records (SQL Paginated) ---")
        print("  1. By item name")
        print("  2. By meal type")
        print("  3. By date")
        print("  4. Show all")
        choice = input("  Choose 1-4: ").strip()
        if choice == "1":
            kw = input("  Keyword: ").strip()
            self._print_paginated(keyword=kw)
        elif choice == "2":
            mt = self._prompt_until_valid(
                f"  Meal type ({'/'.join(MEAL_TYPES)}): ", validate_meal_type
            )
            self._print_paginated(meal_type=mt)
        elif choice == "3":
            dt = self._prompt_until_valid("  Date (YYYY-MM-DD): ", validate_date)
            self._print_paginated(date=dt)
        else:
            self._print_paginated()

    def handle_summary(self) -> None:
        records = self.repo.fetch_all()
        cur = self.repo.get_currency()
        limit = self.repo.get_daily_limit()
        print("\n" + "=" * 62)
        print("  SPEND ANALYTICS & BURN-RATE SUMMARY")
        print("=" * 62)
        if not records:
            print("  No records yet. Add a meal or load demo data (Option 6).")
            return

        s = summarise(records, limit)
        print(f"  Items recorded    : {s['entries']}")
        print(f"  Days tracked      : {s['days']}")
        print(f"  Total spent       : {cur}{s['total']:.2f}")
        print(f"  Average per day   : {cur}{s['avg_day']:.2f}")
        print(f"  Average per item  : {cur}{s['avg_item']:.2f}")
        print(f"  Priciest day      : {s['priciest_day'][0]} ({cur}{s['priciest_day'][1]:.2f})")
        print(f"  Cheapest day      : {s['cheapest_day'][0]} ({cur}{s['cheapest_day'][1]:.2f})")
        print(
            f"  7-Day Burn Rate   : {cur}{s['burn_rate']['rolling_avg']:.2f}/day "
            f"(30-day proj: {cur}{s['burn_rate']['projected_30d']:.2f})"
        )

        print("\n  Spending by Category:")
        total = s["total"] or 1.0
        for cat, amount in s["by_category"].items():
            pct = amount / total * 100
            print(f"  {cat:<10} {cur}{amount:>8.2f} ({pct:>5.1f}%) {'#' * int(pct // 4)}")

        print("\n  Days Over Budget:")
        if s["over_budget"]:
            for day, amount in s["over_budget"]:
                print(f"  - {day}: {cur}{amount:.2f} ({cur}{amount - limit:.2f} over)")
        else:
            print("  - None.")

        print("\n  Statistical Anomalies (Z >= 2.0):")
        if s["anomalies"]:
            for item, z in s["anomalies"]:
                print(f"  - {item.date} | {item.meal_type} | {item.item_name}: {cur}{item.total_cost:.2f} (z={z})")
        else:
            print("  - None.")
        print("=" * 62)

    def handle_export(self) -> None:
        records = self.repo.fetch_all()
        if not records:
            print("  Nothing to export yet.")
            return
        j_path, c_path = self.repo.export_json_csv()
        md_path = export_markdown_report(records, self.repo.get_daily_limit(), self.repo.get_currency())
        print(f"  Exported: {md_path}, {j_path}, and {c_path}")

    def handle_import(self) -> None:
        path = input("  CSV path: ").strip()
        try:
            added, rejected, errors = self.repo.import_csv(path)
            for err in errors:
                print(f"  Skipped {err}")
            print(f"  Import complete: {added} added, {rejected} rejected.")
        except FileNotFoundError as err:
            print(f"  {err}")

    def handle_demo(self) -> None:
        ans = input("  Replace current database with 35 demo records? (y/n): ").strip().lower()
        if ans == "y":
            count = self.repo.seed_demo_data()
            print(f"  Loaded {count} demo records into SQLite.")

    def handle_settings(self) -> None:
        cur = self.repo.get_currency()
        limit = self.repo.get_daily_limit()
        print(f"\n--- Settings (Current: {cur}{limit:.2f}/day) ---")
        new_limit = self._prompt_until_valid("  New daily budget limit: ", validate_price)
        self.repo.set_setting("daily_limit", str(new_limit))
        print(f"  Daily budget updated to {cur}{new_limit:.2f}")

    def run(self) -> None:
        count = self.repo.count_meals()
        print("\n" + "=" * 62)
        print("  Daily Meal Cost Calculator (SQLite + Analytics)")
        print("=" * 62)
        print(f"  Connected to SQLite ({count} records).")

        actions = {
            "1": self.handle_add,
            "2": self.handle_search,
            "3": self.handle_summary,
            "4": self.handle_export,
            "5": self.handle_import,
            "6": self.handle_demo,
            "7": self.handle_settings,
        }

        while True:
            print("\nMenu:")
            print("  1. Add a meal")
            print("  2. View / search records (SQL paginated)")
            print("  3. Spend analytics & anomaly summary")
            print("  4. Export reports (Markdown, JSON, CSV)")
            print("  5. Import from CSV")
            print("  6. Load 35 demo records")
            print("  7. Configure daily budget")
            print("  0. Exit")

            choice = input("\nChoose: ").strip()
            if choice == "0":
                logger.info("User exited application.")
                print("  Goodbye!")
                break
            action = actions.get(choice)
            if action:
                action()
            else:
                print("  Please pick a number from 0 to 7.")
