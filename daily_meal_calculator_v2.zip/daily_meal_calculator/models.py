"""Data models and input validation rules for Daily Meal Cost Calculator."""

from dataclasses import dataclass, field
from datetime import datetime
import math
import re

MEAL_TYPES = ("Breakfast", "Lunch", "Dinner", "Snack", "Beverage")
DEFAULT_CURRENCY = "₹"
DEFAULT_DAILY_LIMIT = 700.00
MIN_PRICE, MAX_PRICE = 1.00, 10000.00
MIN_QTY, MAX_QTY = 1, 50
ITEM_NAME_PATTERN = re.compile(r"^[A-Za-z0-9\s\-&()'.]+$")


def validate_item_name(name: str, max_len: int = 40) -> str:
    """Validate and normalize an item name."""
    cleaned = name.strip()
    if not cleaned:
        raise ValueError("Item name cannot be empty.")
    if len(cleaned) > max_len:
        raise ValueError(f"Item name too long (max {max_len} characters).")
    if not ITEM_NAME_PATTERN.match(cleaned):
        raise ValueError("Item name contains unsupported characters.")
    return cleaned


def validate_date(date_str: str) -> str:
    """Validate ISO YYYY-MM-DD date string; empty string defaults to today."""
    cleaned = date_str.strip()
    if not cleaned:
        return datetime.now().strftime("%Y-%m-%d")
    try:
        return datetime.strptime(cleaned, "%Y-%m-%d").strftime("%Y-%m-%d")
    except ValueError as exc:
        raise ValueError("Date must be in YYYY-MM-DD format.") from exc


def validate_meal_type(meal_type: str) -> str:
    """Validate and normalize meal category."""
    cleaned = meal_type.strip().title()
    if cleaned not in MEAL_TYPES:
        raise ValueError(f"Meal type must be one of: {', '.join(MEAL_TYPES)}.")
    return cleaned


def validate_price(price: float) -> float:
    """Validate unit price is finite and within allowed bounds."""
    try:
        val = float(price)
    except (TypeError, ValueError) as exc:
        raise ValueError("Price must be a valid number.") from exc
    if math.isnan(val) or math.isinf(val):
        raise ValueError("Price must be a finite number.")
    if not (MIN_PRICE <= val <= MAX_PRICE):
        raise ValueError(f"Price must be between {MIN_PRICE:.2f} and {MAX_PRICE:.2f}.")
    return round(val, 2)


def validate_quantity(qty: int) -> int:
    """Validate quantity is an integer within allowed bounds."""
    if isinstance(qty, bool):
        raise ValueError("Quantity must be a whole number.")
    try:
        val = int(qty)
    except (TypeError, ValueError) as exc:
        raise ValueError("Quantity must be a whole number.") from exc
    if not (MIN_QTY <= val <= MAX_QTY):
        raise ValueError(f"Quantity must be between {MIN_QTY} and {MAX_QTY}.")
    return val


@dataclass
class MealEntry:
    entry_id: str
    date: str
    meal_type: str
    item_name: str
    unit_price: float
    quantity: int
    daily_limit: float = field(default=DEFAULT_DAILY_LIMIT, repr=False)
    total_cost: float = field(init=False)
    budget_flag: str = field(init=False)

    def __post_init__(self):
        self.date = validate_date(self.date)
        self.meal_type = validate_meal_type(self.meal_type)
        self.item_name = validate_item_name(self.item_name)
        self.unit_price = validate_price(self.unit_price)
        self.quantity = validate_quantity(self.quantity)
        self.total_cost = round(self.unit_price * self.quantity, 2)
        self.budget_flag = "HIGH_COST" if self.total_cost > (self.daily_limit / 2) else "NORMAL"

    def to_dict(self) -> dict:
        return {
            "entry_id": self.entry_id,
            "date": self.date,
            "meal_type": self.meal_type,
            "item_name": self.item_name,
            "unit_price": self.unit_price,
            "quantity": self.quantity,
            "total_cost": self.total_cost,
            "budget_flag": self.budget_flag,
        }
