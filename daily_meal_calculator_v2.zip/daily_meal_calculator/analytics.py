"""Pure analytics engine: aggregations, statistical anomaly detection, and burn-rate projections."""

from collections import defaultdict
from datetime import datetime
import logging
import statistics
from typing import Dict, List, Tuple

from .models import MEAL_TYPES, MealEntry

logger = logging.getLogger(__name__)


def daily_totals(records: List[MealEntry]) -> Dict[str, float]:
    totals: Dict[str, float] = defaultdict(float)
    for r in records:
        totals[r.date] = round(totals[r.date] + r.total_cost, 2)
    return dict(sorted(totals.items()))


def category_totals(records: List[MealEntry]) -> Dict[str, float]:
    totals = {t: 0.0 for t in MEAL_TYPES}
    for r in records:
        totals[r.meal_type] = round(totals[r.meal_type] + r.total_cost, 2)
    return totals


def detect_statistical_anomalies(
    records: List[MealEntry], z_threshold: float = 2.0
) -> List[Tuple[MealEntry, float]]:
    """Flag meals whose total_cost exceeds mean + z_threshold * stdev for their category."""
    by_cat: Dict[str, List[MealEntry]] = defaultdict(list)
    for r in records:
        by_cat[r.meal_type].append(r)

    anomalies: List[Tuple[MealEntry, float]] = []
    for cat, items in by_cat.items():
        if len(items) < 3:
            continue
        costs = [i.total_cost for i in items]
        mean = statistics.mean(costs)
        stdev = statistics.stdev(costs)
        if stdev == 0:
            continue
        for item in items:
            z_score = (item.total_cost - mean) / stdev
            if z_score >= z_threshold:
                anomalies.append((item, round(z_score, 2)))
    return anomalies


def calculate_burn_rate(records: List[MealEntry], window_days: int = 7) -> Dict[str, float]:
    """Compute recent rolling daily average and 30-day projected spend."""
    days = daily_totals(records)
    if not days:
        return {"rolling_avg": 0.0, "projected_30d": 0.0, "window_used": 0}
    recent_totals = list(days.values())[-window_days:]
    rolling_avg = round(sum(recent_totals) / len(recent_totals), 2)
    return {
        "rolling_avg": rolling_avg,
        "projected_30d": round(rolling_avg * 30, 2),
        "window_used": len(recent_totals),
    }


def summarise(records: List[MealEntry], daily_limit: float) -> Dict:
    """Compute comprehensive spend analytics without any UI side effects."""
    if not records:
        return {}
    days = daily_totals(records)
    grand_total = round(sum(r.total_cost for r in records), 2)
    return {
        "entries": len(records),
        "days": len(days),
        "total": grand_total,
        "avg_day": round(grand_total / len(days), 2),
        "avg_item": round(grand_total / len(records), 2),
        "priciest_day": max(days.items(), key=lambda x: x[1]),
        "cheapest_day": min(days.items(), key=lambda x: x[1]),
        "over_budget": [(d, t) for d, t in days.items() if t > daily_limit],
        "by_category": category_totals(records),
        "anomalies": detect_statistical_anomalies(records),
        "burn_rate": calculate_burn_rate(records),
    }


def export_markdown_report(
    records: List[MealEntry],
    daily_limit: float,
    currency: str = "₹",
    path: str = "summary.md",
) -> str:
    """Generate a formatted Markdown audit report and return the file path."""
    if not records:
        raise ValueError("Cannot export report: no records available.")
    s = summarise(records, daily_limit)
    total = s["total"] or 1.0

    lines = [
        "# Meal Cost Summary Report",
        f"Generated: {datetime.now():%Y-%m-%d %H:%M} | Daily Budget: {currency}{daily_limit:.2f}",
        "",
        "## Overview",
        f"- Items recorded: {s['entries']}",
        f"- Days tracked: {s['days']}",
        f"- Total spent: {currency}{s['total']:.2f}",
        f"- Average per day: {currency}{s['avg_day']:.2f}",
        f"- Average per item: {currency}{s['avg_item']:.2f}",
        f"- Most expensive day: {s['priciest_day'][0]} ({currency}{s['priciest_day'][1]:.2f})",
        f"- 7-day rolling burn rate: {currency}{s['burn_rate']['rolling_avg']:.2f}/day "
        f"(Projected 30-day: {currency}{s['burn_rate']['projected_30d']:.2f})",
        "",
        "## Spending by Category",
        "| Category | Spent | Share |",
        "| :--- | ---: | ---: |",
    ]
    for cat, amount in s["by_category"].items():
        lines.append(f"| {cat} | {currency}{amount:.2f} | {amount / total * 100:.1f}% |")

    lines += ["", "## Days Over Budget"]
    if s["over_budget"]:
        for day, amount in s["over_budget"]:
            lines.append(f"- {day}: {currency}{amount:.2f} ({currency}{amount - daily_limit:.2f} over)")
    else:
        lines.append("- No days exceeded the daily budget.")

    lines += ["", "## Statistical Anomalies (Z >= 2.0)"]
    if s["anomalies"]:
        for item, z in s["anomalies"]:
            lines.append(
                f"- {item.date} | {item.meal_type} | {item.item_name}: "
                f"{currency}{item.total_cost:.2f} (z={z})"
            )
    else:
        lines.append("- No statistical outliers detected.")

    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    logger.info("Exported Markdown report to %s", path)
    return path
