# Daily Meal Cost Calculator (v2 — Layered SQLite Architecture)

A zero-dependency Python CLI application for validated meal tracking, SQLite persistence with indexed pagination, statistical anomaly detection, and spend analytics.

## Architecture
```text
daily_meal_calculator/
├── models.py      # MealEntry dataclass & strict input validators
├── database.py    # SQLite Data Access Layer (indexes, SQL pagination, JSON/CSV I/O)
├── analytics.py   # Pure analytics engine (Z-score anomalies, 7-day burn rate, Markdown export)
└── cli.py         # Isolated terminal UI layer
main.py            # Entry point + rotating file logging
tests/test_app.py  # Automated unit & integration test suite
```

## Quick Start
```bash
# Run the application
python main.py

# Run the automated test suite (unittest or pytest)
python -m unittest discover -s tests -v
# or
pytest -v
```
